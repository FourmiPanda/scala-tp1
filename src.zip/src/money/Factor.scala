package money

class Factor(val fatcor: Double){

  //implicit def double2factor(d: Double): Account = Account(d, factor);
}
